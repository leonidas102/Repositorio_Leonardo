v=float(input('ingrese el valor de la compra sin comas o puntos '))
i=v*0.19
b=v-i
print('iva   = ',i)
print('valor = ',b)
print('Total = ',v)