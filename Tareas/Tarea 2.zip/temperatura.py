f=float(input('ingrese su temperatura en fahrenheit'))
c=(f-32)*(5/9)
print(f,' grados fahrenheit equivalen a ',c,' grados centigrados')