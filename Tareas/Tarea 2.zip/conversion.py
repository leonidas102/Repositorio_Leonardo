n=float(input('ingrese su medida en pulgadas'))
m=n*25.4
print('sus',n,'pulgadas equivalen a ',m,'milimetros')